def Circumference ( a ) :
    return ( 4 * a )
