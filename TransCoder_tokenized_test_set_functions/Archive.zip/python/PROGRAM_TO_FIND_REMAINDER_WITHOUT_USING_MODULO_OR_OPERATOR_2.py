def getRemainder ( num, divisor ) :
    while ( num >= divisor ) :
        num -= divisor;
        
    return num;
