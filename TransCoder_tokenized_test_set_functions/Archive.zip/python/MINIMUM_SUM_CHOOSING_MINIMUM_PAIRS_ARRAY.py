def minSum ( A ) :
    min_val = min ( A );
    
    return min_val * ( len ( A ) - 1 )
