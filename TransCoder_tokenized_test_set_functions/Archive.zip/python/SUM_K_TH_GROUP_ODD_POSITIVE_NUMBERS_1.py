def kthgroupsum ( k ) :
    return k * k * k
