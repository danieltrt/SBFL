def vol_of_octahedron ( side ) :
    return ( ( side * side * side ) * ( math . sqrt ( 2 ) / 3 ) )
