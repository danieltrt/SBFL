def transpose ( A, B ) :
    for i in range ( N ) :
        for j in range ( N ) :
            B [ i ] [ j ] = A [ j ] [ i ]
    
