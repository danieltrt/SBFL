def findLarger ( arr, n ) :
    x = sorted ( arr )
    for i in range ( n / 2, n ) :
        print ( x [ i ] ),
    
