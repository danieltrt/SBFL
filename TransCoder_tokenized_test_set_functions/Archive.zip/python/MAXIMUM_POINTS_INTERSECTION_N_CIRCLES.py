def intersection ( n ) :
    return n * ( n - 1 );
