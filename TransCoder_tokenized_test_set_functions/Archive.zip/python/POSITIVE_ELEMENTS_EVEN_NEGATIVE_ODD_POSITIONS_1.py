def printArray ( a, n ) :
    for i in a :
        print ( i, end = " " )
    print ( )
