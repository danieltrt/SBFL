def height ( N ) :
    return math . ceil ( math . log2 ( N + 1 ) ) - 1
