def findIndex ( n ) :
    fibo = 2.078087 * math . log ( n ) + 1.672276
    return round ( fibo )
