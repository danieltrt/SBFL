def mergeTwoHalf ( A, n ) :
    A . sort ( )
