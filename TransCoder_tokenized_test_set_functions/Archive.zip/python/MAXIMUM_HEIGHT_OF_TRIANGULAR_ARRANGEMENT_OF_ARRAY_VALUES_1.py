def MaximumHeight ( a, n ) :
    return ( - 1 + int ( math . sqrt ( 1 + ( 8 * n ) ) ) ) //2
