def pentagonalNum ( n ) :
    return ( 3 * n * n - n ) / 2
