def compute_average ( a, b ) :
    return ( a //2)+(b//2)+((a%2+b%2)//2)
