def areaOfInscribedCircle ( a ) :
    return ( PI / 4 ) * a * a
