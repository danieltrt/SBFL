def printSeries ( n ) :
    for i in range ( 1, n + 1 ) :
        num = i * ( i + 1 ) * ( i + 2 ) //6
        print(num,end=' ')
    
