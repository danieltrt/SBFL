def findArea ( r ) :
    PI = 3.142
    return PI * ( r * r );
