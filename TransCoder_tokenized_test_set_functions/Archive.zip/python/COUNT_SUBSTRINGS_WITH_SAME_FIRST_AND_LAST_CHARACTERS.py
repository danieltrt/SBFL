def countSubstringWithEqualEnds ( s ) :
    result = 0;
    
    n = len ( s );
    
    for i in range ( n ) :
        for j in range ( i, n ) :
            if ( s [ i ] == s [ j ] ) :
                result = result + 1
    return result
