def countIntegralSolutions ( n ) :
    return int ( ( ( n + 1 ) * ( n + 2 ) ) / 2 )
