def sortString ( str ) :
    str = '' . join ( sorted ( str ) )
    print ( str )
