def getArea ( a ) :
    area = ( math . pi * a * a ) / 4
    return area
