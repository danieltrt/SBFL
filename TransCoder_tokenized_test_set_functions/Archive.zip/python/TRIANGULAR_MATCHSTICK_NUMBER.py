def numberOfSticks ( x ) :
    return ( 3 * x * ( x + 1 ) ) / 2
