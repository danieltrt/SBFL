def numberOfTriangles ( n ) :
    ans = 2 * ( pow ( 3, n ) ) - 1;
    
    return ans;
