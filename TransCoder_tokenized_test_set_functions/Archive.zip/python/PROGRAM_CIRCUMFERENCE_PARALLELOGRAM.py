def circumferenceparallelogram ( a, b ) :
    return ( ( 2 * a ) + ( 2 * b ) )
