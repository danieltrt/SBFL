def pythagorean_quadruple ( a, b, c, d ) :
    sum = a * a + b * b + c * c;
    
    if ( d * d == sum ) :
        return True
    else :
        return False
    
