def volumeOfEllipsoid ( r1, r2, r3 ) :
    return 1.33 * math . pi * r1 * r2 * r3
