def countNonEmptySubstr ( str ) :
    n = len ( str );
    
    return int ( n * ( n + 1 ) / 2 );
