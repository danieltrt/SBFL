def isPossible ( str, n ) :
    l = len ( str )
    if ( l >= n ) :
        return True
    return False
