def search ( arr, n, x ) :
    i = 0
    for i in range ( i, n ) :
        if ( arr [ i ] == x ) :
            return i
    return - 1
