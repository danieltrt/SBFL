def assignValue ( a, b, x ) :
    arr = [ a, b ]
    return ( arr [ x ] )
