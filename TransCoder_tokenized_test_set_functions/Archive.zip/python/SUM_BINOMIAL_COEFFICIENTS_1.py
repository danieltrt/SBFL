def binomialCoeffSum ( n ) :
    return ( 1 << n );
