int maxSquare ( int b , int m ) {
  return ( b / m - 1 ) * ( b / m ) / 2 ;
}
