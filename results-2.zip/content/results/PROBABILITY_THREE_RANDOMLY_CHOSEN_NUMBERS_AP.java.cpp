double procal ( int n ) {
  return ( 3.0 * n ) / ( 4.0 * ( n * n ) - 1 ) ;
}
