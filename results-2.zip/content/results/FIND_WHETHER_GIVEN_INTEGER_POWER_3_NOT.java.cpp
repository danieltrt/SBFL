bool check ( int n ) {
  return 1162261467 % n == 0 ;
}
