int addOne ( int x ) {
  return ( - ( ~ x ) ) ;
}
