double areaOfInscribedCircle ( float a ) {
  return ( PI / 4 ) * a * a ;
}
