void midpoint ( int x1 , int x2 , int y1 , int y2 ) {
  cout << ( x1 + x2 ) / 2 << " , " << ( y1 + y2 ) / 2 << endl ;
}
