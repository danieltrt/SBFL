int hexagonalNum ( int n ) {
  return n * ( 2 * n - 1 ) ;
}
