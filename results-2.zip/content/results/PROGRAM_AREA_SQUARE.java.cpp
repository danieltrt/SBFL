int area_square ( int side ) {
  int area = side * side ;
  return area ;
}
