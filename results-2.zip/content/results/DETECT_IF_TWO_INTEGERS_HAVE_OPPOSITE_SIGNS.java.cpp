bool oppositeSigns ( int x , int y ) {
  return ( ( x ^ y ) < 0 ) ;
}
