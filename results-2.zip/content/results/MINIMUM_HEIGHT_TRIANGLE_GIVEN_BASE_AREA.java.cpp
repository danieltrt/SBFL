double minHeight ( double base , double area ) {
  double d = ( 2 * area ) / base ;
  return ceil ( d ) ;
}
