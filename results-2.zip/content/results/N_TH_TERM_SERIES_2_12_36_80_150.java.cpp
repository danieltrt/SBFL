int nthTerm ( int n ) {
  return ( n * n ) + ( n * n * n ) ;
}
