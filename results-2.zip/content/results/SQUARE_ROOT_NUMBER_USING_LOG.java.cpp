double squareRoot ( double n ) {
  return pow ( 2 , 0.5 * ( log ( n ) / log ( 2 ) ) ) ;
}
