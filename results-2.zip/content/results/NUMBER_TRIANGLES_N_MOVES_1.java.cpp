double numberOfTriangles ( int n ) {
  double ans = 2 * ( pow ( 3 , n ) ) - 1 ;
  return ans ;
}
