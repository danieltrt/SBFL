int lis ( int arr [ ] , int n ) {
  max_ref = 1 ;
  _lis ( arr , n ) ;
  return max_ref ;
}
