int MaximumHeight ( int a [ ] , int n ) {
  return ( int ) floor ( ( - 1 + sqrt ( 1 + ( 8 * n ) ) ) / 2 ) ;
}
