int evenbinomialCoeffSum ( int n ) {
  return ( 1 << ( n - 1 ) ) ;
}
