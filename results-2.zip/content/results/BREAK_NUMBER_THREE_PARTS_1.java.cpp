long long count_of_ways ( long long n ) {
  long long count = 0 ;
  count = ( n + 1 ) * ( n + 2 ) / 2 ;
  return count ;
}
