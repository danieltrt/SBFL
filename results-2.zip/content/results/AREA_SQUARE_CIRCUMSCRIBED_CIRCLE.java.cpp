int find_Area ( int r ) {
  return ( 2 * r * r ) ;
}
