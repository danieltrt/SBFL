double findArea ( int r ) {
  return PI * pow ( r , 2 ) ;
}
