int fun ( int n ) {
  return n & ( n - 1 ) ;
}
