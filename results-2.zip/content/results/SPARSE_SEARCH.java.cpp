int sparseSearch ( string arr [ ] , string x , int n ) {
  return binarySearch ( arr , 0 , n - 1 , x ) ;
}
