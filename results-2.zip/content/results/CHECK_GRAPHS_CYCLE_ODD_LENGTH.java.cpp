int countNonZero ( int v ) {
  int count = 0 ;
  for ( int i = 0 ;
  i < V ;
  ++ i ) {
    count ++ ;
  }
  return count ;
}
