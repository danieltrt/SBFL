float findArea ( float a ) {
  float area ;
  area = ( float ) ( sqrt ( 5 * ( 5 + 2 * ( sqrt ( 5 ) ) ) ) * a * a ) / 4 ;
  return area ;
}
