double vol_of_octahedron ( double side ) {
  return ( ( side * side * side ) * ( sqrt ( 2 ) / 3 ) ) ;
}
