int multiplyBySeven ( int n ) {
  return ( ( n << 3 ) - n ) ;
}
